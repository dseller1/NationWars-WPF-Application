NATION-WARS APP README

ATTACK CALC TAB:

Calculates whether or not you will be able to successfully grab your target. Gives you a % and recommended troops to send to minimize readiness loss while still successfully attacking.

Paste your military info from the PM into the left side.

Ex:
State Summary 		                     Nation Army Summary
Spies: 19.213.051 	   Level:8 	    Spies 	22.094.143
Infantry: 37.712.978 	   Level:8 	    Infantry 	250.137.528
Tanks: 0 	           Level:1 	    Tanks 	0
Jets: 6.658.184 	   Level:8 	    Jets 	6.527.914
Bombers: 0 	           Level:12 	    Bombers 	4
SAMs: 20.284.490 	   Level:8 	    SAMs 	13.390.733
Ships: 999.999.999	   Level:8 	    Ships	27.992.014

Paste enemies military info from a Military Espionage spy report in the Saved Intel page.

MAKE SURE IT'S FROM THE SAVED INTELS PAGE. AFTER YOU INTEL SOMEONE GO TO THE SAVED INTEL PAGE TO RETREIVE THE REPORT

Ex:
Military Espionage Report
State: Rawr(#156)[Rawr]
Readiness 100%
Intelligence Readiness 100%
Army 	                   Nation Army 	      Upgrades
Spies: 123.123.120 	   123.123.120 	       Level:7
Infantry: 157.883.719 	   280.223.407 	       Level:8
Tanks: 123.123.120 	   123.123.123 	       Level:1
Jets: 123.123.120 	   123.123.120 	       Level:8
Bombers: 123.123.120 	   123.123.120 	       Level:1
SAMs: 123.123.120 	   123.123.120 	       Level:1
Ships: 123.123.120 	   123.123.120 	       Level:8

The readiness textboxes are editable. If you change either readiness hit the Recalculate button.


LAND GRAB TAB:

Calculates what you can expect to get from a grab. Just input the values into the text boxes.


CASHER TAB:

Helps tell you what buildings to build for recommended Comm:Res Ratio. Just input your current values into the text boxes.


WAR CALC TAB:

Calculates estimated amount of attacks for either GA or AR kills. Input value into text box and hit calculate.


SETTINGS TAB:

Can change your display name here.